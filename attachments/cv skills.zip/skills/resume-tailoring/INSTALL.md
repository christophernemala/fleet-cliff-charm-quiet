# Install Resume Tailoring Skill in Claude Code

## Manual install

1. Create the Claude skills folder:

```bash
mkdir -p ~/.claude/skills/resume-tailoring
```

2. Copy every file from this `resume-tailoring` folder into:

```bash
~/.claude/skills/resume-tailoring
```

3. Restart Claude Code.

4. Run:

```bash
/skills
```

You should see `resume-tailoring` in the skills list.

## Recommended project structure

```text
project-folder/
├── resumes/
│   ├── master-resume.md
│   ├── ar-collections-resume.md
│   └── finance-operations-resume.md
├── job-descriptions/
│   └── target-role.md
└── outputs/
```

## Example Claude prompt

```text
Use the resume-tailoring skill.
Tailor my resume for this job description.
Keep it factual, ATS optimized, two pages, and focused on Senior Accounts Receivable, Credit Control, O2C, Collections, Billing, Reconciliation, Cash Application, IFRS 9 ECL, month-end closing, audit support, Oracle Fusion, SAP, Excel, and Power BI.
Do not invent metrics. Use only verified experience from my resume library.
Create a markdown resume and an ATS gap report.
```
