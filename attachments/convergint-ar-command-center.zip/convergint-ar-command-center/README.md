# Convergint AR Command Center

Premium internal Accounts Receivable command center prototype.

## Design Standard
Built against the public premium-ui-design skill:
https://github.com/christophernemala/premium-ui-design-skill

- Deep graphite surfaces
- Restrained violet-blue iridescence / Convergint blue accents
- Subtle glass depth
- 150–220 ms spring-style transitions
- Dense, readable finance tables (no decorative 3D over data)
- Poppins (titles) + Roboto (UI/data)

## Pages
- `/login` – secure sign-in, SSO, MFA-ready
- Dashboard – KPIs, ageing, top overdue, action queue
- Ageing – full matrix with frozen column, filters, SOA PDF
- Reconciliation – bank txns + confidence-scored matches
- Forecast – base / best / downside scenarios
- Admin – roles & entity permissions
- Customer 360 – exposure, activity, SOA generation

## How to run
Simply open `index.html` in a modern browser (Chrome / Edge / Firefox).
No build step required. All data is realistic placeholder AED multi-entity AR data.

## Security notes (prototype)
- Frontend only – no real secrets
- Generic error messaging pattern demonstrated
- Audit-style UI for decisions
- Reduced-motion support via CSS

## Stack
HTML • Tailwind CSS (CDN) • Chart.js • Vanilla JS client-side routing
Fonts: Poppins, Roboto, Lato
